
createmean <- function(x) {
        answer <- mean(x)       
        return(answer)
}